package com.alchemyst.hololauncher.ui

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily

/** Change this to your own name for the greeting ("GOOD EVENING, ..."). */
const val OPERATOR_NAME = "OPERATOR"

object Hud {
    val Bg = Color(0xFF04060A)
    val Cyan = Color(0xFF38BDF8)
    val Red = Color(0xFFFF3B4E)
    val Text = Color(0xFFD7ECFA)
    val Dim = Color(0xFF6B8399)
}

val Mono = FontFamily.Monospace
