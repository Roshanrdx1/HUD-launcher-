package com.alchemyst.hololauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap

data class AppInfo(
    val label: String,
    val packageName: String,
    val icon: ImageBitmap,
)

object AppRepository {

    private const val PREFS = "holo_launcher"
    private const val KEY_PINNED = "pinned"

    /** All launchable apps (except this launcher), sorted A-Z. Call off the main thread. */
    fun loadApps(context: Context): List<AppInfo> {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        val results = pm.queryIntentActivities(intent, 0)
        return results
            .filter { it.activityInfo.packageName != context.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                AppInfo(
                    label = ri.loadLabel(pm).toString(),
                    packageName = ri.activityInfo.packageName,
                    icon = ri.loadIcon(pm).toBitmap(96, 96).asImageBitmap(),
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    /** Wheel apps used until the user pins something themselves: dialer, messages, browser, camera... */
    fun defaultPinned(context: Context, apps: List<AppInfo>, max: Int = 8): List<String> {
        val pm = context.packageManager
        val installed = apps.map { it.packageName }.toSet()
        val picks = mutableListOf<String>()

        fun add(pkg: String?) {
            if (pkg != null && pkg in installed && pkg !in picks) picks.add(pkg)
        }

        fun pkgOf(intent: Intent): String? =
            pm.resolveActivity(intent, 0)?.activityInfo?.packageName

        add(pkgOf(Intent(Intent.ACTION_DIAL)))
        add(pkgOf(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)))
        add(pkgOf(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_BROWSER)))
        add(pkgOf(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)))
        add(pkgOf(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)))
        add(pkgOf(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MAPS)))
        add(pkgOf(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)))
        add(pkgOf(Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_EMAIL)))

        for (app in apps) {
            if (picks.size >= max) break
            add(app.packageName)
        }
        return picks.take(max)
    }

    /** null = user never customised the wheel (use defaults). */
    fun getPinned(context: Context): List<String>? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_PINNED, null) ?: return null
        return raw.split("|").filter { it.isNotBlank() }
    }

    fun setPinned(context: Context, pkgs: List<String>) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_PINNED, pkgs.joinToString("|")).apply()
    }

    fun launch(context: Context, packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }
}
