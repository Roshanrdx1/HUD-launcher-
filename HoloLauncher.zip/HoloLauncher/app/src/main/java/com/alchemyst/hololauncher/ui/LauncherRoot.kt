package com.alchemyst.hololauncher.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.drawscope.Stroke
import android.content.res.Configuration
import androidx.compose.material3.Text
import com.alchemyst.hololauncher.AppInfo
import com.alchemyst.hololauncher.AppRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private enum class Screen { HOME, ALL_APPS, EDIT_WHEEL }

@Composable
fun LauncherRoot() {
    val ctx = LocalContext.current
    val apps by produceState<List<AppInfo>>(emptyList()) {
        value = withContext(Dispatchers.IO) { AppRepository.loadApps(ctx) }
    }

    var pinned by remember(apps) {
        mutableStateOf(
            AppRepository.getPinned(ctx)?.filter { p -> apps.any { it.packageName == p } }
                ?: AppRepository.defaultPinned(ctx, apps)
        )
    }
    var screen by remember { mutableStateOf(Screen.HOME) }
    var page by remember { mutableStateOf(0) }

    val byPkg = remember(apps) { apps.associateBy { it.packageName } }
    val wheelApps = pinned.mapNotNull { byPkg[it] }
    val pageCount = maxOf(1, (wheelApps.size + SLOTS - 1) / SLOTS)
    if (page >= pageCount) page = pageCount - 1
    val pageItems = wheelApps.drop(page * SLOTS).take(SLOTS)

    BackHandler(enabled = screen != Screen.HOME) { screen = Screen.HOME }

    Box(
        Modifier
            .fillMaxSize()
            .background(Hud.Bg)
    ) {
        GridBackdrop()
        when (screen) {
            Screen.HOME -> HomeScreen(
                pageItems = pageItems,
                pageCount = pageCount,
                page = page,
                onPage = { page = it },
                onLaunch = { AppRepository.launch(ctx, it.packageName) },
                onOpenDrawer = { screen = Screen.ALL_APPS },
                onEditWheel = { screen = Screen.EDIT_WHEEL },
            )
            Screen.ALL_APPS -> AppDrawer(
                apps = apps,
                onLaunch = { AppRepository.launch(ctx, it.packageName) },
                onClose = { screen = Screen.HOME },
                title = "ALL APPS // TAP TO LAUNCH",
            )
            Screen.EDIT_WHEEL -> AppDrawer(
                apps = apps,
                pinned = pinned,
                onToggle = { pkg ->
                    pinned = if (pkg in pinned) pinned - pkg else pinned + pkg
                    AppRepository.setPinned(ctx, pinned)
                },
                onLaunch = {},
                onClose = { screen = Screen.HOME },
                title = "EDIT WHEEL // TAP TO PIN",
            )
        }
    }
}

@Composable
private fun GridBackdrop() {
    Canvas(Modifier.fillMaxSize()) {
        val step = 36.dp.toPx()
        val col = Hud.Cyan.copy(alpha = 0.05f)
        var x = 0f
        while (x < size.width) {
            drawLine(col, Offset(x, 0f), Offset(x, size.height), 1f); x += step
        }
        var y = 0f
        while (y < size.height) {
            drawLine(col, Offset(0f, y), Offset(size.width, y), 1f); y += step
        }
        drawRect(
            Brush.radialGradient(
                listOf(Color.Transparent, Hud.Bg),
                center = center, radius = maxOf(size.width, size.height) * 0.75f,
            )
        )
    }
}

@Composable
private fun HomeScreen(
    pageItems: List<AppInfo>,
    pageCount: Int,
    page: Int,
    onPage: (Int) -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onOpenDrawer: () -> Unit,
    onEditWheel: () -> Unit,
) {
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    val wheel: @Composable (Modifier) -> Unit = { m ->
        HoloWheel(
            items = pageItems,
            pageCount = pageCount,
            page = page,
            onPageChange = onPage,
            onLaunch = onLaunch,
            onCenterTap = onOpenDrawer,
            modifier = m,
        )
    }

    if (landscape) {
        Row(
            Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Column(Modifier.weight(1f)) { ClockBlock() ; Spacer(Modifier.height(12.dp)); StatusBlock() }
            wheel(Modifier.fillMaxHeight().aspectRatio(1f))
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                DockButtons(onOpenDrawer, onEditWheel)
                Spacer(Modifier.height(12.dp))
                PageDots(pageCount, page)
            }
        }
    } else {
        Column(
            Modifier
                .fillMaxSize()
                .safeDrawingPadding()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                ClockBlock()
                StatusBlock(alignEnd = true)
            }
            Spacer(Modifier.weight(1f))
            wheel(Modifier.fillMaxWidth().aspectRatio(1f))
            PageDots(pageCount, page)
            Spacer(Modifier.weight(1f))
            DockButtons(onOpenDrawer, onEditWheel)
            Spacer(Modifier.height(8.dp))
        }
    }
}

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    val g = when {
        h < 5 -> "GOOD NIGHT"
        h < 12 -> "GOOD MORNING"
        h < 17 -> "GOOD AFTERNOON"
        h < 21 -> "GOOD EVENING"
        else -> "GOOD NIGHT"
    }
    return "$g, $OPERATOR_NAME"
}

@Composable
private fun ClockBlock() {
    val now by produceState(Date()) {
        while (true) {
            value = Date()
            delay(1000)
        }
    }
    val time = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
    val sec = SimpleDateFormat("ss", Locale.getDefault()).format(now)
    val date = SimpleDateFormat("EEE · dd MMM", Locale.getDefault()).format(now).uppercase()
    Column {
        Text(greeting(), color = Hud.Cyan, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 2.sp)
        Row(verticalAlignment = Alignment.Bottom) {
            Text(time, color = Hud.Text, fontFamily = Mono, fontSize = 46.sp, fontWeight = FontWeight.Bold)
            Text(
                sec, color = Hud.Red, fontFamily = Mono, fontSize = 16.sp,
                modifier = Modifier.padding(start = 6.dp, bottom = 8.dp),
            )
        }
        Text(date, color = Hud.Dim, fontFamily = Mono, fontSize = 12.sp, letterSpacing = 2.sp)
    }
}

@Composable
private fun StatusBlock(alignEnd: Boolean = false) {
    val ctx = LocalContext.current
    val battery by produceState(BatteryInfo(0, false)) {
        while (true) {
            value = readBattery(ctx)
            delay(15_000)
        }
    }
    Column(horizontalAlignment = if (alignEnd) Alignment.End else Alignment.Start) {
        Text("PWR", color = Hud.Dim, fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp)
        Text(
            "${battery.percent}%" + if (battery.charging) " ⚡" else "",
            color = if (battery.percent <= 15 && !battery.charging) Hud.Red else Hud.Cyan,
            fontFamily = Mono, fontSize = 22.sp, fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .width(90.dp)
                .height(4.dp)
                .border(1.dp, Hud.Cyan.copy(alpha = 0.5f))
        ) {
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(battery.percent / 100f)
                    .background(if (battery.percent <= 15) Hud.Red else Hud.Cyan)
            )
        }
        Spacer(Modifier.height(4.dp))
        Text("SYS // ONLINE", color = Hud.Dim, fontFamily = Mono, fontSize = 10.sp, letterSpacing = 2.sp)
    }
}

private data class BatteryInfo(val percent: Int, val charging: Boolean)

private fun readBattery(ctx: Context): BatteryInfo {
    val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, 0) ?: 0
    val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
    val status = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
    val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
        status == BatteryManager.BATTERY_STATUS_FULL
    return BatteryInfo(if (scale > 0) level * 100 / scale else 0, charging)
}

@Composable
private fun PageDots(count: Int, page: Int) {
    if (count <= 1) return
    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        for (i in 0 until count) {
            Box(
                Modifier
                    .size(if (i == page) 10.dp else 6.dp)
                    .clip(androidx.compose.foundation.shape.CircleShape)
                    .background(if (i == page) Hud.Red else Hud.Cyan.copy(alpha = 0.4f))
            )
        }
    }
}

@Composable
private fun DockButtons(onApps: () -> Unit, onEdit: () -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        HudButton("ALL APPS", onApps)
        HudButton("EDIT WHEEL", onEdit)
    }
}

@Composable
private fun HudButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .border(1.dp, Hud.Cyan.copy(alpha = 0.7f))
            .background(Hud.Cyan.copy(alpha = 0.08f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = Hud.Cyan, fontFamily = Mono, fontSize = 12.sp, letterSpacing = 2.sp)
    }
}

/**
 * Used for both the full app list (pinned == null) and the wheel editor (pinned != null).
 */
@Composable
private fun AppDrawer(
    apps: List<AppInfo>,
    onLaunch: (AppInfo) -> Unit,
    onClose: () -> Unit,
    title: String,
    pinned: List<String>? = null,
    onToggle: ((String) -> Unit)? = null,
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query.trim(), ignoreCase = true) }
    }

    Column(
        Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .padding(16.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                title, color = Hud.Cyan, fontFamily = Mono, fontSize = 12.sp,
                letterSpacing = 2.sp, modifier = Modifier.weight(1f),
            )
            HudButton("CLOSE", onClose)
        }
        Spacer(Modifier.height(12.dp))
        Box(
            Modifier
                .fillMaxWidth()
                .border(1.dp, Hud.Cyan.copy(alpha = 0.6f))
                .background(Hud.Cyan.copy(alpha = 0.06f))
                .padding(12.dp)
        ) {
            if (query.isEmpty()) {
                Text("> SEARCH", color = Hud.Dim, fontFamily = Mono, fontSize = 14.sp)
            }
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = Hud.Text, fontFamily = Mono, fontSize = 14.sp),
                cursorBrush = SolidColor(Hud.Red),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.fillMaxSize()) {
            items(filtered, key = { it.packageName }) { app ->
                val isPinned = pinned?.contains(app.packageName) == true
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable {
                            if (onToggle != null) onToggle(app.packageName) else onLaunch(app)
                        }
                        .padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Image(app.icon, contentDescription = app.label, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.width(14.dp))
                    Text(
                        app.label.uppercase(), color = Hud.Text, fontFamily = Mono,
                        fontSize = 14.sp, letterSpacing = 1.sp, modifier = Modifier.weight(1f),
                    )
                    if (pinned != null) {
                        Text(
                            if (isPinned) "[ PINNED ]" else "[  +  ]",
                            color = if (isPinned) Hud.Red else Hud.Dim,
                            fontFamily = Mono, fontSize = 12.sp,
                        )
                    }
                }
            }
        }
    }
}
