package com.alchemyst.hololauncher.ui

import android.graphics.Typeface
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.ui.unit.dp
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.alchemyst.hololauncher.AppInfo
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import android.graphics.Paint as AndroidPaint

const val SLOTS = 8
private const val SLOT_DEG = 360f / SLOTS
private const val CENTER_HIT = -2

/** -2 = centre core, -1 = nothing, 0..SLOTS-1 = app slot (slot 0 is at 12 o'clock, clockwise). */
private fun hitTest(off: Offset, size: IntSize): Int {
    val cx = size.width / 2f
    val cy = size.height / 2f
    val r = min(size.width, size.height) / 2f
    val dx = off.x - cx
    val dy = off.y - cy
    val d = sqrt(dx * dx + dy * dy)
    if (d < r * 0.45f) return CENTER_HIT
    if (d < r * 0.52f || d > r * 0.82f) return -1
    val ang = Math.toDegrees(atan2(dy, dx).toDouble()).toFloat()
    val rel = ((ang + 90f + SLOT_DEG / 2f) % 360f + 360f) % 360f
    return (rel / SLOT_DEG).toInt().coerceIn(0, SLOTS - 1)
}

@Composable
fun HoloWheel(
    items: List<AppInfo>,
    pageCount: Int,
    page: Int,
    onPageChange: (Int) -> Unit,
    onLaunch: (AppInfo) -> Unit,
    onCenterTap: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val t = rememberInfiniteTransition(label = "hud")
    val spin by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(70_000, easing = LinearEasing)), label = "spin",
    )
    val spinRev by t.animateFloat(
        360f, 0f, infiniteRepeatable(tween(28_000, easing = LinearEasing)), label = "rev",
    )
    val fast by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(9_000, easing = LinearEasing)), label = "fast",
    )
    val pulse by t.animateFloat(
        0.35f, 1f,
        infiniteRepeatable(tween(1_800, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "pulse",
    )

    var pressed by remember { mutableIntStateOf(-1) }
    val curItems by rememberUpdatedState(items)
    val curPage by rememberUpdatedState(page)
    val curCount by rememberUpdatedState(pageCount)
    val curLaunch by rememberUpdatedState(onLaunch)
    val curCenter by rememberUpdatedState(onCenterTap)
    val curPageChange by rememberUpdatedState(onPageChange)

    val paint = remember {
        AndroidPaint().apply {
            isAntiAlias = true
            typeface = Typeface.MONOSPACE
            textAlign = AndroidPaint.Align.CENTER
        }
    }

    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = { o ->
                        val h = hitTest(o, size)
                        pressed = if (h in 0 until SLOTS && h < curItems.size) h else -1
                        tryAwaitRelease()
                        pressed = -1
                    },
                    onTap = { o ->
                        val h = hitTest(o, size)
                        if (h == CENTER_HIT) curCenter()
                        else if (h >= 0 && h < curItems.size) curLaunch(curItems[h])
                    },
                )
            }
            .pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = {
                        if (total < -90f && curPage < curCount - 1) curPageChange(curPage + 1)
                        else if (total > 90f && curPage > 0) curPageChange(curPage - 1)
                    },
                    onHorizontalDrag = { _, d -> total += d },
                )
            },
    ) {
        val c = center
        val r = min(size.width, size.height) / 2f
        val hair = 1.dp.toPx()

        // soft glow
        drawCircle(
            brush = Brush.radialGradient(
                listOf(Hud.Cyan.copy(alpha = 0.16f), Color.Transparent),
                center = c, radius = r,
            ),
            radius = r, center = c,
        )

        // outer hairline + rotating tick ring
        drawCircle(Hud.Cyan.copy(alpha = 0.35f), radius = r * 0.985f, center = c, style = Stroke(hair))
        rotate(spin, c) {
            for (i in 0 until 120) {
                val a = Math.toRadians(i * 3.0)
                val len = if (i % 5 == 0) r * 0.045f else r * 0.022f
                val dir = Offset(cos(a).toFloat(), sin(a).toFloat())
                drawLine(
                    Hud.Cyan.copy(alpha = if (i % 10 == 0) 0.9f else 0.45f),
                    c + dir * (r * 0.985f),
                    c + dir * (r * 0.985f - len),
                    strokeWidth = hair,
                )
            }
        }

        // counter-rotating dashed ring
        rotate(spinRev, c) {
            drawCircle(
                Hud.Cyan.copy(alpha = 0.5f), radius = r * 0.915f, center = c,
                style = Stroke(hair, pathEffect = PathEffect.dashPathEffect(floatArrayOf(r * 0.03f, r * 0.02f))),
            )
            drawArc(
                Hud.Red, 20f, 30f, false,
                topLeft = c - Offset(r * 0.915f, r * 0.915f),
                size = Size(r * 1.83f, r * 1.83f),
                style = Stroke(hair * 3f),
            )
            drawArc(
                Hud.Red, 200f, 14f, false,
                topLeft = c - Offset(r * 0.915f, r * 0.915f),
                size = Size(r * 1.83f, r * 1.83f),
                style = Stroke(hair * 3f),
            )
        }

        // app segments
        val rIn = r * 0.52f
        val rOut = r * 0.78f
        val mid = (rIn + rOut) / 2f
        val thick = rOut - rIn
        for (i in 0 until SLOTS) {
            val start = -90f + i * SLOT_DEG - SLOT_DEG / 2f + 1.6f
            val sweep = SLOT_DEG - 3.2f
            val has = i < items.size
            val isPressed = pressed == i

            val fill = when {
                isPressed -> Hud.Red.copy(alpha = 0.55f)
                has -> Hud.Cyan.copy(alpha = 0.12f)
                else -> Hud.Cyan.copy(alpha = 0.04f)
            }
            drawArc(
                fill, start, sweep, false,
                topLeft = c - Offset(mid, mid), size = Size(mid * 2, mid * 2),
                style = Stroke(thick),
            )
            val edge = when {
                isPressed -> Hud.Red
                has -> Hud.Cyan.copy(alpha = 0.8f)
                else -> Hud.Cyan.copy(alpha = 0.25f)
            }
            drawArc(
                edge, start, sweep, false,
                topLeft = c - Offset(rOut, rOut), size = Size(rOut * 2, rOut * 2),
                style = Stroke(hair * 1.5f),
            )
            drawArc(
                edge.copy(alpha = edge.alpha * 0.6f), start, sweep, false,
                topLeft = c - Offset(rIn, rIn), size = Size(rIn * 2, rIn * 2),
                style = Stroke(hair),
            )

            if (has) {
                val a = Math.toRadians((-90f + i * SLOT_DEG).toDouble())
                val p = c + Offset(cos(a).toFloat(), sin(a).toFloat()) * mid
                val s = (thick * 0.62f).roundToInt()
                drawImage(
                    items[i].icon,
                    dstOffset = IntOffset((p.x - s / 2f).roundToInt(), (p.y - s / 2f).roundToInt()),
                    dstSize = IntSize(s, s),
                    alpha = if (isPressed) 1f else 0.92f,
                )
            }
        }

        // labels curved around the ring (flipped on the bottom half so they stay readable)
        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            paint.textSize = r * 0.045f
            for (i in 0 until min(items.size, SLOTS)) {
                val deg = -90f + i * SLOT_DEG
                val a = Math.toRadians(deg.toDouble())
                val px = c.x + cos(a).toFloat() * r * 0.85f
                val py = c.y + sin(a).toFloat() * r * 0.85f
                val bottom = sin(a) > 0.1
                val rot = if (bottom) deg - 90f else deg + 90f
                paint.color = (if (pressed == i) Hud.Red else Hud.Text).toArgb()
                nc.save()
                nc.rotate(rot, px, py)
                nc.drawText(items[i].label.uppercase().take(10), px, py + paint.textSize / 3f, paint)
                nc.restore()
            }
        }

        // centre core
        val rc = r * 0.45f
        drawCircle(Hud.Bg, radius = rc, center = c)
        drawCircle(Hud.Cyan.copy(alpha = 0.5f), radius = rc, center = c, style = Stroke(hair * 1.5f))
        rotate(fast, c) {
            drawArc(
                Hud.Red, 0f, 70f, false,
                topLeft = c - Offset(r * 0.485f, r * 0.485f), size = Size(r * 0.97f, r * 0.97f),
                style = Stroke(hair * 3f),
            )
            drawArc(
                Hud.Red, 180f, 20f, false,
                topLeft = c - Offset(r * 0.485f, r * 0.485f), size = Size(r * 0.97f, r * 0.97f),
                style = Stroke(hair * 3f),
            )
        }
        drawCircle(Hud.Cyan.copy(alpha = 0.35f), radius = r * 0.34f, center = c, style = Stroke(hair))
        drawCircle(Hud.Text.copy(alpha = 0.9f), radius = r * 0.25f, center = c, style = Stroke(hair * 2.5f))
        // swirl
        for (k in 0 until 5) {
            val rad = r * (0.05f + k * 0.034f)
            val dir = if (k % 2 == 0) fast else -fast
            rotate(dir + k * 70f, c) {
                drawArc(
                    Hud.Text.copy(alpha = 0.35f + k * 0.1f), 0f, 200f - k * 20f, false,
                    topLeft = c - Offset(rad, rad), size = Size(rad * 2, rad * 2),
                    style = Stroke(hair * 1.6f, cap = StrokeCap.Round),
                )
            }
        }
        drawCircle(Hud.Cyan.copy(alpha = pulse * 0.7f), radius = r * 0.035f, center = c)
    }
}
